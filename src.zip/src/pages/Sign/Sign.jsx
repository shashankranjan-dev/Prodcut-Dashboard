import React from "react";
import Signbody from "../../components/Sign/Signbody";

function Sign() {
  return (
    <div className="app">
      <Signbody />;
    </div>
  );
}

export default Sign;
