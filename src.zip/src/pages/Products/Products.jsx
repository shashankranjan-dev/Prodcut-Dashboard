import React from "react";
import ProductsBody from "../../components/Products/ProductsBody";

function Products() {
  return <ProductsBody />;
}

export default Products;
