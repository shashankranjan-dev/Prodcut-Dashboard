import React from 'react'
import SignUp from '../../components/Sign/SignUp'

function Log() {
  return (
    <div>
        <SignUp />
    </div>
  )
}

export default Log